Sample configuration files for:
```
SystemD: bitcoinrentd.service
Upstart: bitcoinrentd.conf
OpenRC:  bitcoinrentd.openrc
         bitcoinrentd.openrcconf
CentOS:  bitcoinrentd.init
macOS:    org.bitcoinrent.bitcoinrentd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
